%Jack Allen: adapted from matlab file exchange: https://uk.mathworks.com/matlabcentral/answers/94495-how-can-i-create-animated-gif-images-in-matlab
%note: animated gifs can be made using imagej, which is perhaps
%quicker/easier than using this function.

h = figure;
axis tight manual % this ensures that getframe() returns a consistent size
filename = 'newGif.gif';

chosenDir = uigetdir;
cd(chosenDir)
imageFileNames = uigetfile('*.dcm','multiselect','on');

for imageIndex = 1:size(imageFileNames,2)
data(:,:,imageIndex) = dicomread(char(imageFileNames(1,imageIndex)));
end

%% make gif
caxisMaxMin = input('Enter greyscale range [max, min]\n')
for n = 1:size(data,3)
    imagesc(squeeze(abs(data(:,:,n))))
    %caxis([0 max(data(:))])
    caxis(caxisMaxMin)
    colormap gray
    colorbar
    axis off
    text(10, 10,num2str(n),'color','white');
    set(gcf,'color','w');
    %drawnow 
      % Capture the plot as an image 
      frame = getframe(h); 
      im = frame2im(frame); 
      [imind,cm] = rgb2ind(im,4096); 
      % Write to the GIF File 
      if n == 1 
          imwrite(imind,cm,filename,'gif', 'DelayTime',0,'Loopcount',inf); 
      else 
          imwrite(imind,cm,filename,'gif','DelayTime',0,'WriteMode','append'); 
      end 
  end